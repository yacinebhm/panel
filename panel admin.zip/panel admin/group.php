<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Contact-us </title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon">
                            <img src="assets/imgs/limose1.png" alt="Small Image">
                        </span>
                        <span class="title">Limose Laboratory</span>
                    </a>
                </li>

                <li>
                    <a href="index.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="member.php">
                        <span class="icon">
                            <ion-icon name="person-add-outline"></ion-icon>
                            
                        </span>
                        <span class="title">Members</span>
                    </a>
                </li>

                <li>
                    <a href="event.php">
                        <span class="icon">
                            <ion-icon name="golf-outline"></ion-icon>
                        </span>
                        <span class="title">Events</span>
                    </a>
                </li>

                <li>
                    <a href="group.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Groups</span>
                    </a>
                </li>

                <li>
                    <a href="admin.php">
                        <span class="icon">
                            <ion-icon name="person-circle-outline"></ion-icon>
                        </span>
                        <span class="title">Admins</span>
                    </a>
                </li>

                <li>
                    <a href="uni.php">
                        <span class="icon">
                        <ion-icon name="school-outline"></ion-icon>
                        </span>
                        <span class="title">University</span>
                    </a>
                </li>

                <li>
                    <a href="demande_event.php">
                        <span class="icon">
                            
                        </span>
                        <span class="title">Demande Event</span>
                    </a>
                </li>

                <li>
                    <a href="contact-us.php">
                        <span class="icon">
                            <ion-icon name="file-tray-full-outline"></ion-icon>
                        </span>
                        <span class="title">Contact-us</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>

                <div class="search">
                    <label>
                        <input type="text" placeholder="Search here">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>

                <div class="user">
                    <img src="assets/imgs/customer01.jpg" alt="">
                </div>
        
</div>               

                <!-- Affichage du tableau de contacts -->
         
         
       <div class="content">
              <!-- Bouton pour ajouter des administrateurs -->
            <button onclick="window.location.href='addgr.php'" style="margin-left: 20px;">Add Team</button>
             <h2>Teams</h2>
             <table>
                        <thead>
                           <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>DESCRIPTION</th>
                                <th>MODIFY</th>
                                <th>DELETE</th>
                           </tr>
                        </thead>
                    <tbody>
                        <?php
                            // Connexion à la base de données MySQL
                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "limos";

                            $conn = new mysqli($servername, $username, $password, $dbname);

                            // Vérifier la connexion
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            // Requête SQL pour sélectionner les données du tableau
                            $sql = "SELECT id, nom, description FROM equipe";

                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                // Afficher les données
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row["id"] . "</td>";
                                    echo "<td>" . $row["nom"] . "</td>";
                                    echo "<td>" . $row["description"] . "</td>";
                                   
                                    // Boutons Modifier et Supprimer
                                    echo "<td>";
                                    echo "<button onclick=\"window.location.href='modifygr.php?id=" . $row["id"] . "'\" class='btn-modifier'>Modify</button>";
                                    echo "<td>";
                                    echo "<button onclick=\"confirmDelete(" . $row["id"] . ")\"class='btn-supprimer'>Delete</button>";
                                    
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "0 results";
                                    }
                                $conn->close();
                        ?>
                    </tbody>
              </table>
       </div>
     
       <script>
        function confirmDelete(id) {
            if (confirm("Voulez-vous supprimer cette equipe ?")) {
                  window.location.href = "deletegr.php?id=" + id;
            }
        }
       </script>


     <!-- =========== Scripts =========  -->
     <script src="assets/js/main.js"></script>

     <!-- ====== ionicons ======= -->
     <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
 </body>

 </html>