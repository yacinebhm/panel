<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style1.css">
    <title>Ajouter</title>
</head>
<body>








<div class="container">
<form  method="post">
       <div class="box">
        <div class="header">
            <header><img src="assets\images\limos.jpg" alt=""></header>
            <p>Add Member</p>
        </div>
       
        <div class="input-box">
            <label for="fname">First Name</label>
            <input type="text"  name="fname">
            
        </div>
        <div class="input-box">
            <label for="lname">Last Name</label>
            <input type="text"  name="lname" >
            
        </div>
       
        

        <div class="input-box">
            <label for="mail">E-Mail</label>
            <input type="email"  name="mail" >
            <i class="bx bx-envelope"></i>
        </div>
        <div class="input-box">
            <label for="pass">Password</label>
            <input type="password" name="pass" >
            <i class="bx bx-lock"></i>
        </div>
        
            <input type="submit" name="add_user" value="ADD">
        </div>
    </form>
       
    </div>

</body>
</html>