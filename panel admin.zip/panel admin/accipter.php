<?php
// Vérifier si l'ID de la demande est passé en paramètre dans l'URL
if (isset($_GET['id'])) {
    // Récupérer l'ID de la demande
    $id_demande = $_GET['id'];

    // Connexion à la base de données MySQL
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Requête SQL pour sélectionner les informations de la demande à partir de l'ID
    $sql = "SELECT id_utilisateur, id_universite, id_event FROM demande_participation_event WHERE id = $id_demande";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Récupérer les informations de la demande
        $row = $result->fetch_assoc();
        $id_utilisateur = $row['id_utilisateur'];
        $id_universite = $row['id_universite'];
        $id_event = $row['id_event'];

        // Requête SQL pour récupérer l'e-mail de l'utilisateur à partir de son ID
        $sql_email = "SELECT email FROM utilisateur_ins WHERE id = $id_utilisateur";
        $result_email = $conn->query($sql_email);

        if ($result_email->num_rows > 0) {
            // Récupérer l'e-mail de l'utilisateur
            $row_email = $result_email->fetch_assoc();
            $email_utilisateur = $row_email['email'];

            
            // Envoyer l'e-mail à l'utilisateur
            $to = $email_utilisateur;
            $subject = "Votre demande a été acceptée";
            $message = "Bonjour,\n\nVotre demande a été acceptée.\n\nCordialement,\nVotre équipe.";
            $headers = "From: Limose_Laboratory@gmail.com";

            // Envoyer l'e-mail
            mail($to, $subject, $message, $headers);

            // Afficher un message de succès
            echo "<script>alert('E-mail envoyé avec succès.');</script>";
        } else {
            echo "L'utilisateur associé à cette demande n'a pas d'adresse e-mail enregistrée.";
        }
    } else {
        echo "Aucune demande trouvée avec cet ID.";
    }

    // Fermer la connexion à la base de données
    $conn->close();
} else {
    echo "ID de demande non spécifié.";
}
?>
