<?php
// Vérifier si l'ID est présent dans l'URL
if (isset($_GET['id'])) {
    // Récupérer l'ID de l'administrateur à modifier
    $id = $_GET['id'];

    // Vérifier si le formulaire a été soumis
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupérer les nouvelles valeurs des champs du formulaire
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
       

        // Connexion à la base de données MySQL
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "limos";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérifier la connexion
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Préparer la requête SQL pour mettre à jour les données dans la table
        $sql = "UPDATE equipe SET nom='$fname', description='$lname' WHERE id='$id'";

        // Exécuter la requête SQL
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Equipe modifier avec succès.'); window.location.href = 'group.php';</script>";

        
        } else {
            echo "Error updating Equipe: " . $conn->error;
        }

        // Fermer la connexion à la base de données
        $conn->close();
    } else {
        // Afficher le formulaire avec les informations de l'administrateur à modifier
        // Connexion à la base de données MySQL
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "limos";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérifier la connexion
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Requête SQL pour récupérer les données de l'administrateur
        $sql = "SELECT * FROM equipe WHERE id='$id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Afficher le formulaire pré-rempli avec les informations de l'administrateur
            while ($row = $result->fetch_assoc()) {
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style1.css">
    <title>Modify Limose Teams</title>
</head>

<body>
    <div class="container">
        <form method="post">
            <div class="box">
                <div class="header">
                    <header><img src="assets\images\limos.jpg" alt=""></header>
                    <p>Modify Limose Teams</p>
                </div>
                <div class="input-box">
                    <label for="fname">NAME</label>
                    <input type="text" name="fname" value="<?php echo $row['nom']; ?>">
                </div>
                <div class="input-box">
                    <label for="lname">DESCRIPTION</label>
                    <input type="text" name="lname" value="<?php echo $row['description']; ?>">
                </div>
                
                <input type="submit" name="update_user" value="UPDATE">
            </div>
        </form>
    </div>
</body>

</html>
<?php
            }
        } else {
            echo "Equipe not found";
        }

        // Fermer la connexion à la base de données
        $conn->close();
    }
} else {
    echo "Equipe ID not provided";
}
?>
